# mypackage
This library was created as an example of how to publish python package
## building this package locally
'python setup.py sdist'

##installing this from Github
'pip install git+https://github.com/Mzwandile/myproject.git'
##updating this package from Github
'pip install --upgrade+https://github.com/Mzwandile/myproject.git'
